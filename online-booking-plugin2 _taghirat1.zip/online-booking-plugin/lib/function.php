<?php

/** 
 * This function return plugin url
 *
 * @param string $option chose the which url you want.'home','siteurl' or null
 *  
 * @return string 
 *  link of your page you define in option.<br>
 *  if option is null return the pluing url
 */
function plugin_url($option = NULL)
{
	$url = $_SERVER['SERVER_NAME'] . dirname(__FILE__);
	$array = explode('/',$url);
	$count = count($array);
	$pdn = $array[$count-2];
	
	switch ($option) {
		case 'home':
			return  get_option('home');
			break;
		
		case 'siteurl':
			return  get_option('siteurl');
			break;
		default:
			return get_option('home')."/wp-content/plugins/$pdn/";			
			break;
	}
}

/**
 * This function return the current url of page
 *
 * @param boolean $filterGET if set true,filter the get values in return url
 *
 * @return string current url of page
 */
function currentPageUrl($filterGET = false)
	{
	    $result = 'http';
	    if (isset($_SERVER["HTTPS"]) and $_SERVER["HTTPS"] == "on") {
	        $result .= "s";
	    }
	    $result .= "://";
	    if ($_SERVER["SERVER_PORT"] != "80") {
	        $result .= $_SERVER["SERVER_NAME"] . ":" . $_SERVER["SERVER_PORT"] . $_SERVER["REQUEST_URI"];
	    } else {
	        $result .= $_SERVER["SERVER_NAME"] . $_SERVER["REQUEST_URI"];
	    }
	   if($filterGET == true)
	    {
	    	$result = explode('?',$result);
	    	$result = $result[0];
	    }
	    return $result;
	}

/**
 * This function check the remaining cpacity of the events
 *
 * @param int $eid the ids of filed you want to check capacity
 *
 * @return int return the remaining capacity of event
 */
function check_cpacity($eid)
{
	global $wpdb;
	
	$sql = 'SELECT COUNT(*) FROM '.$wpdb->prefix.'online_booking_plugin_booking where b_eid = "'.$eid.'"';
	
	$event_list = $wpdb->get_results( 'SELECT * FROM `'.$wpdb->prefix.'online_booking_plugin_events` WHERE `e_eid`="'.$eid.'"' );
	//echo $wpdb->last_query;
	$number =  $wpdb->num_rows;
	if($number > 0) {
		//$arr = array('new_capacity' => 1, 'new_price' => 2);
		foreach ($event_list as $event_row )
		{
			if(($event_row->e_capacity - $wpdb->get_var( $sql )) <=0)
				return 0;				
			else
				return $event_row->e_capacity - $wpdb->get_var( $sql );									
		}
	}
	else
	{
		if((get_option('online_booking_plugin_default_capacity') - $wpdb->get_var( $sql )) <=0)
			return 0;
		else
			return get_option('online_booking_plugin_default_capacity')-$wpdb->get_var( $sql );
	}
}

function explort_backup()
{
	$data_backup_booking  = db_select('online_booking_plugin_booking','*');
	$data_backup_events   = db_select('online_booking_plugin_events','*');
	$data_backup_calendar = db_select('online_booking_plugin_calendar','*');
	$data_backup_mail     = db_select('online_booking_plugin_mail','*');
	
	
	if($data_backup_booking != NULL)
		for($i=0;$i<count($data_backup_booking);$i++)
			foreach($data_backup_booking[$i] as $key => $data)
				$data_backup['online_booking_plugin_booking'][$i][$key] = base64_encode($data);
			
	if($data_backup_events != NULL)
		for($i=0;$i<count($data_backup_events);$i++)
			foreach($data_backup_events[$i] as $key => $data)
				$data_backup['online_booking_plugin_events'][$i][$key] = base64_encode($data);
	
	if($data_backup_calendar != NULL)
		for($i=0;$i<count($data_backup_calendar);$i++)
			foreach($data_backup_calendar[$i] as $key => $data)
				$data_backup['online_booking_plugin_calendar'][$i][$key] = base64_encode($data);
			
	if($data_backup_mail != NULL)	
		for($i=0;$i<count($data_backup_mail);$i++)
			foreach($data_backup_mail[$i] as $key => $data)
				$data_backup['online_booking_plugin_mail'][$i][$key] = base64_encode($data);
	$file_name = 'data.bk';
	if (file_exists(dirname(__FILE__).'/../'.$file_name))
		unlink(dirname(__FILE__).'/../'.$file_name);
			
	if(file_put_contents(dirname(__FILE__).'/../'.$file_name, json_encode($data_backup)) == true)
		return $file_name;

	return false; 
}

function import_backup($File)
{

	$temp = explode(".", $File["name"]);
	$extension = end($temp);
	
	$upload_response = true;
	
	if ($File["size"] <= 0 || $extension != "bk")
		$upload_response = false;
	
	if ($File["error"] > 0)
		$upload_response = false; 
	
	if($upload_response == true)
	{			
		$file_name = "re_data.bk";
		if (file_exists(dirname(__FILE__).'/../'.$file_name))
			unlink(dirname(__FILE__).'/../'.$file_name);
		
		move_uploaded_file($File["tmp_name"],dirname(__FILE__).'/../'.$file_name);
		
		$restore_data = file_get_contents(dirname(__FILE__).'/../'.$file_name);		

		$restore_data = json_decode($restore_data);
		
		drop_plugin_table();
		create_plugin_table();
		
		foreach($restore_data as $key => $data)
		{			
			
			foreach( $data as $key1 => $data1)
			{
				foreach( $data1 as $key2 => $data2)
					$restore_data_arr[$key][$key1][$key2] = base64_decode($data2);
						db_insert($key, $restore_data_arr[$key][$key1]);
			}
		}

		unlink(dirname(__FILE__).'/../'.$file_name);
	}
	return $upload_response;
}	





