/* 
* load the event info 
*/
jQuery(document).ready(function() {

	jQuery('#calendar').fullCalendar({
		header: {
			left: 'prev,next today',
			center: 'title',
			right: 'month,agendaWeek,agendaDay'
		},
		eventRender: function (event, element) {
			element.attr('href', 'javascript:void(0);');
			element.click(function() {
				jQuery("#estartTime").val(moment(event.start).format('YYYY-MM-DD H:mm:ss'));
				jQuery("#eendTime").val(moment(event.end).format('YYYY-MM-DD H:mm:ss'));
				jQuery("#startTime").html(moment(event.start).format('MMM Do h:mm A'));
				jQuery("#endTime").html(moment(event.end).format('MMM Do h:mm A'));
				jQuery("#eid").val(event.id);
				jQuery("#etitle").val(event.title);
				jQuery("#eventContent").dialog({ modal: true, title: event.title, width:350});
				
				// hide the booking and email alert
				
				jQuery( "#info_loading" ).show();
				jQuery( "#corser_form" ).hide();
				jQuery( "#error_loading" ).hide();			    
				
				jQuery( "#alert_0" ).hide();
				jQuery( "#alert_1" ).hide();
				jQuery( "#alert_2" ).hide();
				jQuery( "#alert_3" ).hide();
				// document.getElementById("corser_form").setAttribute("style", "display: none;");
				// show the Price and Capacity
				var price_capacity_info = true;
				var eid = jQuery("#eid").val();
				var title = jQuery("#etitle").val();
				var default_capacity = <?php echo @$capacity_value; /* this var load in calendar_edit_config_setting_page.php file */ ?> ;
				var default_price = <?php echo @$price_value; /* this var load in calendar_edit_config_setting_page.php file */  ?>;
				jQuery.ajax({
					type:'POST',
					data:{
						'action' : 'online_booking_plugin_do_ajax',
						'eid': eid,
						'etitle':title,
						'cid':<?php echo $id_value; /* this var load in calendar_edit_config_setting_page.php file */ ?>,
						'price_capacity_info':price_capacity_info,
						'overall_capacity': true,
					},
					url: "<?php echo plugin_url("home") ?>/admin_url( 'admin-ajax.php', '' )",
					success: function(value) {
						if(value == 'error')
						{
							jQuery( "#info_loading" ).hide();
							jQuery( "#error_loading" ).show();
						}
						else{
							obj = JSON.parse(value);
							if(obj.default == true)
							{
								jQuery("#new_capacity").val(default_capacity);
								jQuery("#new_price").val(default_price);
								document.getElementById("defalut_value_check").checked = true;
							}
							else
							{
								jQuery("#new_capacity").val(obj.capacity);
								jQuery("#new_price").val(obj.price);
								jQuery("#new_discription").val(obj.discription);
								document.getElementById("defalut_value_check").checked = false;
								
							}
							changeForm();						
							jQuery( "#info_loading" ).hide();
							jQuery( "#corser_form" ).show();
						}						
					}
				});
			});
		},
		//defaultDate: '2015-02-12',
		editable: true,
		eventLimit: true, // allow "more" link when too many events
		events: {
			//url: 'cal.php',
			url: '<?php echo plugin_url(); ?>auth/<?php echo '?cid='.$_GET['subpage']; ?>',
			error: function() {
				jQuery('#script-warning').show();
			} , 
			success: function() {
				jQuery('#script-warning').hide()	
			}
		},
		loading: function(bool) {
			jQuery('#loading').toggle(bool);
		}
	});
	
});
////////////////////////
/*
* Event Customization
*/

function changeForm() {
	var default_capacity = <?php echo @$capacity_value; /* this var load in calendar_edit_config_setting_page.php file */ ?> ;
	var default_price = <?php echo @$price_value; /* this var load in calendar_edit_config_setting_page.php file */  ?>;
 	
        if(jQuery('#defalut_value_check').is(":checked")) {
            document.getElementById('new_capacity').disabled = true; 
            document.getElementById('new_price').disabled = true; 
            document.getElementById('new_discription').disabled = true; 
            document.getElementById("new_capacity").setAttribute("style", "background-color: #eee;");
            document.getElementById("new_price").setAttribute("style", "background-color: #eee;");
            document.getElementById("new_discription").setAttribute("style", "background-color: #eee;resize : none;");
            jQuery("#new_capacity").val(default_capacity);
	    jQuery("#new_price").val(default_price);
	    jQuery("#new_discription").val('');
        }
        else{
        	document.getElementById('new_capacity').disabled = false; 
        	document.getElementById('new_price').disabled = false; 
            	document.getElementById('new_discription').disabled = false; 
            	document.getElementById("new_capacity").setAttribute("style", "background-color: #FFF;");
            	document.getElementById("new_price").setAttribute("style", "background-color: #FFF;");
            	document.getElementById("new_discription").setAttribute("style", "background-color: #FFF;");
        }

   }
function confirm_alert() {
    confirm("Are you sure ti set default value?");
}
jQuery("#sendit").click(function(){
	if(jQuery('#defalut_value_check').is(":checked")){
		if (!window.confirm("Are you sure ti set default value?")) { 
			exit();
		}
	}
	
	if(jQuery('#new_capacity').val() == "") {
		document.getElementById("new_capacity").setAttribute("style", "border-color: RED;");				 
		exit();
	}

	
	if(jQuery('#new_price').val() == "") {
		document.getElementById("new_price").setAttribute("style", "border-color: RED;");			 
		exit();
	}

	changeForm();
	
	jQuery( "#alert_0" ).hide();
	jQuery( "#alert_1" ).hide();
	jQuery( "#alert_2" ).hide();
	jQuery( "#alert_3" ).hide();
	
	jQuery("#alert_booking").html('');			
	jQuery( "#alert_booking" ).hide();
	
	var eid = jQuery("#eid").val();
	var title = jQuery("#etitle").val();
	var estarttime = jQuery("#estartTime").val();
	var eendtime = jQuery("#eendTime").val();
	var defalut_value_check = jQuery("#defalut_value_check").val();
	
	if(jQuery('#defalut_value_check').is(":checked"))
		var defalut_value_check = jQuery("#defalut_value_check").val();
	else
		var defalut_value_check = "new";
	
	var new_capacity = jQuery("#new_capacity").val();;			
	var new_price = jQuery("#new_price").val();
	var new_discription = jQuery("#new_discription").val();
	jQuery.ajax({
		type:'POST',
		data:{
			'action' : 'online_booking_plugin_do_ajax',
			'eid': eid,
			'cid':<?php echo $id_value; /* this var load in calendar_edit_config_setting_page.php file */ ?>,
			'etitle':title,
			'estarttime':estarttime,
			'eendtime':eendtime,
			'defalut_value_check':defalut_value_check,
			'new_capacity':new_capacity,
			'new_price':new_price,
			'new_discription':new_discription,
			'price_capacity_customize':'true',
		},
		url: "<?php echo plugin_url('home') ?>/admin_url( 'admin-ajax.php', '' )",
		success: function(value) {
			if(value == '0')
			{
				jQuery( "#alert_0" ).show();
			}
			else if(value == '1')
			{
				jQuery( "#alert_1" ).show();
			}
			else if(value == '2')
			{
				jQuery( "#alert_2" ).show();
			} 
			else if(value == '3')
			{
				jQuery( "#alert_3" ).show();
			} 	
		}
	});
});

