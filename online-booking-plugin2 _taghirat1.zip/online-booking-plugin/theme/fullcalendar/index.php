<?php
//require_once("../config.php");
$main_url = $url;
$url = $url . "fullcalendar/";
//include("theme/fullcalendar.php")
?>