/* 
* load the event info 
*/
jQuery(document).ready(function() {
	jQuery('#calendar').fullCalendar({
		header: {
			left: 'prev,next today',
			center: 'title',
			right: 'month,agendaWeek,agendaDay'
		},
		eventRender: function (event, element) {
		        element.attr('href', 'javascript:void(0);');
		        element.click(function() {
		            jQuery("#estartTime").val(moment(event.start).format('YYYY-MM-DD H:mm:ss'));
		            jQuery("#eendTime").val(moment(event.end).format('YYYY-MM-DD H:mm:ss'));
		            jQuery("#startTime").html(moment(event.start).format('MMM Do h:mm A'));			           
		            jQuery("#endTime").html(moment(event.end).format('MMM Do h:mm A'));
		            jQuery("#eid").val(event.id);
		            jQuery("#etitle").val(event.title);
		            jQuery("#eventContent").dialog({ modal: true, title: event.title, width:350});
		            
		            // hide the booking and email alert
		            jQuery("#alert_booking").html('');			
			    jQuery( "#alert_booking" ).hide();
		 	    jQuery( "#alert_email" ).hide();
		 	    jQuery( "#alert_0" ).hide();
			    jQuery( "#alert_1" ).hide();
			    jQuery( "#alert_2" ).hide();
			    jQuery( "#alert_3" ).hide();
		 	    jQuery( "#info_loading" ).show();
		 	    jQuery( "#info_data" ).hide();
		 	    jQuery( "#error_loading" ).hide();
			   
			    jQuery("#price_capacity_data").html('');
			    jQuery( "#price_capacity_data" ).hide();
		 	    jQuery( "#discription_display" ).hide();
		 	    
		 	    // show the Price and Capacity
		 	    var price_capacity_info = true;
		 	    var eid = jQuery("#eid").val();
			    var title = jQuery("#etitle").val();				    
		            jQuery.ajax({
				    type:'POST',
				    data:{
					'action':'online_booking_plugin_do_ajax',
					'eid': eid,
					'etitle':title,	
					'cid':<?php echo $calendar_id['id']  ?>,
					'price_capacity_info':price_capacity_info
					},
						url: "<?php echo plugin_url('home') ?>/admin_url( 'admin-ajax.php', '' )",
						success: function(value) {
							
							jQuery( "#price_capacity_loading" ).hide();
							if(value == 'error')
							{
								jQuery( "#info_loading" ).hide();
								jQuery( "#error_loading" ).show();
							}
							else{
								obj = JSON.parse(value);
								if(obj.capacity > 0)
									jQuery("#capacity_data").html(obj.capacity);
								else
									jQuery("#capacity_data").html('Finishing capacity , <strong>you can be on waiting list</strong><br>');
								jQuery("#price_data").html(obj.price);
								if(obj.discription)
								{	
									jQuery("#discription_data").html(obj.discription);
									jQuery( "#discription_display" ).show();
								}
							
								jQuery( "#info_loading" ).hide();
								jQuery( "#info_data" ).show();
							}
						}
				});
			});
		 },
		//defaultDate: '2015-02-12',
		editable: true,
		eventLimit: true, // allow "more" link when too many events
		events: {
			//url: 'cal.php',
			url: '<?php echo plugin_url(); ?>auth/<?php echo '?cid='.$calendar_id['id']; ?>',
			error: function() {
				jQuery('#script-warning').show();
			} , 
			success: function() {
				jQuery('#script-warning').hide()	
			}
		},
		loading: function(bool) {
			jQuery('#loading').toggle(bool);
		}
	});

});

////////////////////////////
/*
* booking function
*/
jQuery("#sendit").click(function(){
	if(jQuery('#email_address').val() == "") {
		 jQuery( "#alert_email" ).show();
		exit();
	}
	else{
	 	jQuery( "#alert_email" ).hide();
	}					
	jQuery( "#alert_0" ).hide();
	jQuery( "#alert_1" ).hide();
	jQuery( "#alert_2" ).hide();
	jQuery( "#alert_3" ).hide();
	
	var eid = jQuery("#eid").val();
	var title = jQuery("#etitle").val();
	var email = jQuery("#email_address").val();
	var estarttime = jQuery("#estartTime").val();
	var eendtime = jQuery("#eendTime").val();			
	 jQuery.ajax({
	  type:'POST',
	  data:{
		'action':'online_booking_plugin_do_ajax',
		'user_booking_email' : 'true',
		'eid': eid,
		'cid':<?php echo $calendar_id['id']  ?>,
		'etitle':title,
		'email':email,
		'estarttime':estarttime,
		'eendtime':eendtime
					},
	  url: "<?php echo $base_url ?>/admin_url( 'admin-ajax.php', '' )",
	  success: function(value) {
	    
	        jQuery("#email_address").val("");                            
	    
		if(value == '0')
		{
			jQuery( "#alert_0" ).show();
		}
		else if(value == '1')
		{
			jQuery( "#alert_1" ).show();
		}
		else if(value == '2')
		{
			jQuery( "#alert_2" ).show();
		} 
		else if(value == '3')
		{
			jQuery( "#alert_3" ).show();
		} 								                          
	  }
	});
});