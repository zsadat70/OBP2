<div class="wrap">
    <h2>Backup Setting</h2>
    <div id="poststuff" style="direction: ltr;">
        <div id="post-body" class="metabox-holder columns-2">
            <div id="post-body-content">
            	<h4>Export Data Backup</h4>
            	<p>
            		Explort the all of the plugin data
            	</p>
            	<?php if(isset($back_url_download) && $back_url_download != false):?>
            		<a href="<?php echo $back_url_download; ?>" style="text-decoration: none;" download><input type="submit" value="Download Backup" /></a>
            	<?php else: ?>
		<form action="" method="post">
    			<input type="hidden" name="action" value="export-backup" />
			<input type="submit" value="Create Backup" />
		</form>
		<?php endif; ?>    
            </div>
        </div>
        <hr>
        <div id="post-body" class="metabox-holder columns-2">
            <div id="post-body-content">
	    	<h4>Import Backup Data</h4>
		<form action="" method="post" enctype="multipart/form-data">
			<input type="file" name="online_booking_plugin_bk_file" id="maps_booking_bk_system_file">
    			<input type="hidden" name="action" value="import-backup" />
			<input type="submit" value="<?php _e('Upload') ?>" />
    			<p style="color:red">
    				<?php if(isset($upload_response)&&$upload_response == false) echo "Error! the file is invalied ";  ?>
    			</p>
    			<p style="color:green">
    				<?php if(isset($upload_response)&&$upload_response == true) echo "Restore the data";  ?>
    			</p>
		</form>     
            </div>
        </div>
    </div>
</div>
