plugin requirement:

    * php version latest 5.4
    * display error is off


add event in calendar requirement:
    set the visiblty event public

/*
Plugin Name: maps-booking-system
Plugin URI: http://mohsentm.ir
Description: booking system on the top of google calendar
Version: 2.9 beta
Author: Seyed Mohsen Hosseini
Author URI: http://mohsentm.ir
License: GPL
*/

=== Plugin Name ===
Contributors: Fablabplatform
Donate link: http://fablabplatform.com
Requires php at least: 5.4
Tested up to: 5.4
Stable tag: 1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

booking system on the top of google calendar

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload the plugin files to the `/wp-content/plugins/plugin-name` directory, or install the plugin through the WordPress plugins screen directly.
1. Activate the plugin through the 'Plugins' screen in WordPress
1. Use the Settings->Plugin Name screen to configure the plugin
1. (Make your instructions match the desired user flow for activating and installing your plugin. Include any steps that might be needed for explanatory purposes)


== Frequently Asked Questions ==

= A question that someone might have =

An answer to that question.

= What about foo bar? =

Answer to foo bar dilemma.


== Changelog ==

= 2.9 =
* Add the auto update.
* Add the backup.


